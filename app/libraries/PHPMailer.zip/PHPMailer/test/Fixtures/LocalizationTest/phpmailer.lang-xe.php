<?php

/**
 * Test fixture.
 *
 * Used in the `PHPMailer\LocalizationTest` to test the fall-back logic.
 */

$PHPMAILER_LANG['empty_message'] = 'XE Lang file found';
